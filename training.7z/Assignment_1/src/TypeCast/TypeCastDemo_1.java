package TypeCast;

public class TypeCastDemo_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		    double d=88888.126;
		    float f=(float)d;
		    System.out.println("float num:"+f);
			
	}

}
