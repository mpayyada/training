package modified_PassCost;

public class Sum_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		int n=5;
		int sum=0;
		
		for(i=0;i<=n;i++)
		{
			sum=sum+i;
		}
		System.out.println("sum is"+sum);
	}

}
