package modified_PassCost;

public class pattern_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,n=10;
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
