package modified_PassCost;

public class star_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int i,j;
       int n=5;
            for(i=1;i<n;i++)
             {
            	for(j =1;j<=n;j++)
            	{
            		if(j>=n)
            		{
            			System.out.print("*");
            		}
            		else
            		{
            			System.out.print(" ");
            		}
	           	
            	}
            	System.out.println();
	
	        }
	}

}
