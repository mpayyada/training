package modified_PassCost;

public class star_6 {

	public static void main(String[] args) {
		//System.out.println("gsdfastdfts");
		// TODO Auto-generated method stub
		 int i,j,k,count=0;
	       int n=10;
	            for(i=0;i<n;i++)
	             {//count=count++;
	            	for(j =0;j<n;j++)
	            	{ 
	            		 k=n-i;
	            		 if(j>=k)
	            		 {
	            		 System.out.print("*");
	            		 }
	            		 else
	            		 {
	            			 System.out.print(" ");
	            		 }
	    			 
	            	}
	            	System.out.println(); }
	         
	             
	            for(i=0;i<n;i++)
	             {//count=count++;
	            	for(j =0;j<n;j++)
	            	{ 
	            		 
	            		if(i<=j)
	            		 {
	            		 System.out.print("*");
	            		 }
	            		 else
	            		 {
	            			 System.out.print(" ");
	            		 }
	            		 
	            		 
	            		
	    			 
	          }
	            	System.out.println(); }
	           
		
	
	
	}
	
}


	
